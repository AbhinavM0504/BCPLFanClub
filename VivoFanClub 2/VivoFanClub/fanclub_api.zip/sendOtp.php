<?php 
    include 'init.php';
 
    //set time zone
    date_default_timezone_set("Asia/Kolkata");
    
    //This function will send the otp 
    function sendOtp($conn, $name, $number, $otp){
	 
	    $curl = curl_init();
	    curl_setopt_array($curl, array(
	    CURLOPT_URL => "http://sms.jaipursmshub.in/api_v2/message/send",
        CURLOPT_RETURNTRANSFER => true,
	    CURLOPT_ENCODING => "",
	    CURLOPT_MAXREDIRS => 10,
	    CURLOPT_TIMEOUT => 30,
	    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	    CURLOPT_CUSTOMREQUEST => "POST",
	    CURLOPT_POSTFIELDS => "sender_id=RJVIVO&dlt_template_id=1207162563624984462&message=Your Verification Code is ".$otp.". Team Vivo Rajasthan&mobile_no='".$number."'",
	    CURLOPT_HTTPHEADER => array(
		    "authorization: Bearer bRjbloPfvBU-2mHgdvI49XO--ue4Gk_DD6y80CN5liESVhRsGf_R3W8f9JJM_NTt",
	        "cache-control: no-cache",
		    "content-type: application/x-www-form-urlencoded"
	    ),
	    ));

	    $response = curl_exec($curl);
	    $err = curl_error($curl);

	    curl_close($curl);
	
	    if ($err) {
    	    //echo "cURL Error #:" . $err;
    	    return 0;
	    } 
	    else 
	    {
	        $json = json_decode($response);
		    $status_value = $json->success;
		    if($status_value){
		        $time = date('Y-m-d H:i:s');
			    $sql = "INSERT INTO `fan_club_otp_data` (`name`, `number`, `otp`, `time`) VALUES ('".$name."', '".$number."', '".$otp."', '".$time."')";
			    $status = mysqli_query($conn, $sql) ? 1 : 0;
			    return $status;
	        }	
	        else{
	            return 0;
	        }
	    }
    }

    $name = $_POST['name'];
    $number = $_POST['number'];
    $imeiNo = $_POST['imeiNo'];
    $otp = rand(100000, 999999);
    $response = array();
 
    if(isset($name, $number, $imeiNo, $otp)){
    	$response['status'] = false;
	    $response['message'] = "Diwali Lucky Draw contest has been closed now...";
    	/*$check_no_sql = "SELECT * from fan_club_data WHERE `number`='".$number."' OR `imei_no` = '".$imeiNo."'";
    	$result = $conn->query($check_no_sql);
    	if ($result->num_rows > 0) {
    	    $response['status'] = false;
    	    $response['message'] = "This imei number or contact number is already registered...";
    	}
    	else{
    		$status = sendOtp($conn, $name, $number, $otp);
    		if($status){
    		    $response['status'] = true;
    		    $response['message'] = "OTP Sent Successfully...";
    		}
    		else{
    		    $response['status'] = false;
    		    $response['message'] = "Unable to send verification code";
    		}
    	}*/
    }
    else{
        $response['status'] = false;
        // $response['message'] = "Parameters should not be empty";
        $response['message'] = "Diwali Lucky Draw contest has been closed now...";
    }
    
    echo json_encode($response);
    mysqli_close($conn);
?>
 