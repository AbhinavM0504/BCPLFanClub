<?php 
 include 'init.php';
 $name = $_POST['name'];
 $number = $_POST['number'];
 $otp = $_POST['otp'];

echo "Diwali Lucky Draw contest has been closed now...";

/*if(isset($name, $number, $otp)){
	//echo "Lucky draw contest has been closed now!!!!";
	$sql = "SELECT * FROM `fan_club_otp_data` WHERE name = '".$name."' AND `number` = '".$number."' ORDER by `id` DESC LIMIT 1";
	$result = $conn->query($sql);
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$otp_value = "".$row["otp"]."";

			if($otp_value == $otp){
				echo "Verified";
			}
			else{
				echo "Invalid OTP";
			}
		}
	}
	
}
else{
	echo "Parameter should not be empty";
}*/
//Closing the database 
mysqli_close($conn);
?>
 