<?php 
    include 'init.php';

    $response = array();
    $giftData = array();
    
    $sql = "SELECT * FROM `fan_club_all_gift_data` WHERE gift_status = '1'";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
	    while($row = $result->fetch_assoc()) {
		    $temp = [
			    'gift_name'=>"".$row["gift_name"]."",
			    'gift_image'=>"".$row["gift_image"]."",
			    'gift_category'=>"".$row["gift_category"].""
		    ];
		    array_push($giftData, $temp);
	    }
	    
	    $response['status'] = true;
        $response['message'] = $giftData;
    }
    else{
        $response['status'] = false;
        $response['message'] = "No gifts available...";
    }
    
    echo json_encode($response);
    mysqli_close($conn);
?>
 