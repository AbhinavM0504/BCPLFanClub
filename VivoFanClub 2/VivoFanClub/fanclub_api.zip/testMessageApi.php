<?php 
include 'init.php';
//$con=mysqli_connect('localhost','root','','vivo');
 
/*function sendOtp($otp, $number){
	 
	$curl = curl_init();
	curl_setopt_array($curl, array(
	  CURLOPT_URL => "http://sms.jaipursmshub.in/api_v2/message/send",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 30,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => "POST",
	  CURLOPT_POSTFIELDS => "sender_id=RJVIVO&dlt_template_id=1207162563624984462&message=Your Verification Code is ".$otp.". Team Vivo Rajasthan&mobile_no='".$number."'",
	  CURLOPT_HTTPHEADER => array(
		"authorization: Bearer bRjbloPfvBU-2mHgdvI49XO--ue4Gk_DD6y80CN5liESVhRsGf_R3W8f9JJM_NTt",
		"cache-control: no-cache",
		"content-type: application/x-www-form-urlencoded"
	  ),
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);
	
	if ($err) {
	  echo "cURL Error #:" . $err;
	} else {
	  //echo "OTP Sent Successfully.. uiihsgfgdhf.";
		echo $response."   Number : ".$number."  OTP : ".$otp ;
	}
}


 //This function will send the otp 
function sendMessage($number){
	 $gift_value = "500 Cashback";
	$curl = curl_init();
	curl_setopt_array($curl, array(
	  CURLOPT_URL => "http://sms.jaipursmshub.in/api_v2/message/send",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 30,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => "POST",
	  CURLOPT_POSTFIELDS => "sender_id=RJVIVO&dlt_template_id=1207163980648921300&message=Thank You for participating in Christmas Lucky Draw Bonanza. 
Congratulations You have won '".$gift_v."'
For more details contact us at {#var#}{#var#}&mobile_no='".$number."'",
	  CURLOPT_HTTPHEADER => array(
		"authorization: Bearer bRjbloPfvBU-2mHgdvI49XO--ue4Gk_DD6y80CN5liESVhRsGf_R3W8f9JJM_NTt",
		"cache-control: no-cache",
		"content-type: application/x-www-form-urlencoded"
	  ),
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);
	
	if ($err) {
	  echo "cURL Error #:" . $err;
	} else {
	  echo "OTP Sent Successfully...";
	}
}*/


function sendOtp($otp, $number){
	 
	$curl = curl_init();
	curl_setopt_array($curl, array(
	  CURLOPT_URL => "http://sms.jaipursmshub.in/api_v2/message/send",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 30,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => "POST",
	  CURLOPT_POSTFIELDS => "sender_id=RJVIVO&dlt_template_id=1207162563624984462&message=Your Verification Code is ".$otp.". Team Vivo Rajasthan&mobile_no='".$number."'",
	  CURLOPT_HTTPHEADER => array(
		"authorization: Bearer bRjbloPfvBU-2mHgdvI49XO--ue4Gk_DD6y80CN5liESVhRsGf_R3W8f9JJM_NTt",
		"cache-control: no-cache",
		"content-type: application/x-www-form-urlencoded"
	  ),
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);
	
	if ($err) {
	  echo "cURL Error #:" . $err;
	} else {
	  echo "OTP Sent Successfully...";
	}
}

//send message
    function sendCongratsMessage($gift_name, $number){
	    $office_number = '9799653222';
	    $curl = curl_init();
    	curl_setopt_array($curl, array(
	        CURLOPT_URL => "http://sms.jaipursmshub.in/api_v2/message/send",
	        CURLOPT_RETURNTRANSFER => true,
	        CURLOPT_ENCODING => "",
    	    CURLOPT_MAXREDIRS => 10,
    	    CURLOPT_TIMEOUT => 30,
    	    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	        CURLOPT_CUSTOMREQUEST => "POST",
    	    CURLOPT_POSTFIELDS => "sender_id=621157&dlt_template_id=1207166564292284055&message=Thank You for participating in vivo Diwali Lucky Draw Bonanza.
Congratulations You have won ".$gift_name."
Bubugao Communication Private Limited&mobile_no='".$number."'",
    	  CURLOPT_HTTPHEADER => array(
    		"authorization: Bearer bRjbloPfvBU-2mHgdvI49XO--ue4Gk_DD6y80CN5liESVhRsGf_R3W8f9JJM_NTt",
    		"cache-control: no-cache",
    		"content-type: application/x-www-form-urlencoded"
    	  ),
    	));
    
    	$response = curl_exec($curl);
    	$err = curl_error($curl);
    
    	curl_close($curl);
    	
    	if ($err) {
    	  echo "cURL Error #:" . $err;
    	} else {
    	  echo "Message Sent Successfully...";
    	}
    }
    
    
    sendCongratsMessage('Cashback 500', '9116802178');
    
/*function sendCongratsMessage($gift_name, $number){
	$office_number = '9799653222';
	 $curl = curl_init();
	curl_setopt_array($curl, array(
	  CURLOPT_URL => "http://sms.jaipursmshub.in/api_v2/message/send",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 30,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => "POST",
	  CURLOPT_POSTFIELDS => "sender_id=RJVIVO&dlt_template_id=1207163980648921300&message=Thank You for participating in Christmas Lucky Draw Bonanza. 
Congratulations You have won '".$gift_name."'
For more details contact us at '".$office_number."'&mobile_no='".$number."'",
	  CURLOPT_HTTPHEADER => array(
		"authorization: Bearer bRjbloPfvBU-2mHgdvI49XO--ue4Gk_DD6y80CN5liESVhRsGf_R3W8f9JJM_NTt",
		"cache-control: no-cache",
		"content-type: application/x-www-form-urlencoded"
	  ),
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);
	
	if ($err) {
	  echo "cURL Error #:" . $err;
	} else {
	  echo "Message Sent Successfully...";
	}
}*/

function sendLuckyDrawMessage($token_no, $number){
	$office_number = '9799653222';
	 $curl = curl_init();
	curl_setopt_array($curl, array(
	  CURLOPT_URL => "http://sms.jaipursmshub.in/api_v2/message/send",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 30,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => "POST",
	  CURLOPT_POSTFIELDS => "sender_id=RJVIVO&dlt_template_id=1207163980682628805&message=Thank You for participating in Christmas Lucky Draw Bonanza.
You are now eligible for Mega Lucky Draw Prize which will be live on 28th December 2021 at vivo official Facebook Page.
Follow us bit.ly/3JcakQv to Join the Facebook live session.
Your Ticket Number is '".$token_no."'.
For more details contact us at '".$office_number."'. &mobile_no='".$number."'",
	  CURLOPT_HTTPHEADER => array(
		"authorization: Bearer bRjbloPfvBU-2mHgdvI49XO--ue4Gk_DD6y80CN5liESVhRsGf_R3W8f9JJM_NTt",
		"cache-control: no-cache",
		"content-type: application/x-www-form-urlencoded"
	  ),
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);
	
	if ($err) {
	  echo "cURL Error #:" . $err;
	} else {
	  echo "Message Sent Successfully...";
	}
}

/*$number = '9116802178';
//ql = "SELECT * from fan_club_data where id < 1693 order by id desc limit 60";
$sql ="SELECT * FROM `fan_club_data` WHERE token_no IN ('XMAS00363', 'XMAS001389', 'XMAS001112')";
$result = $conn->query($sql);
if($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		$id_value =  "".$row["id"]."";
		$token_no_value =  "".$row["token_no"]."";
		$number_value =  "".$row["number"]."";
		sendLuckyDrawMessage($token_no_value, $number_value);
		echo $id_value." "."<br>";
	}
	
}


//luck draw message
//$token_no = 'XMAS0000';
//sendLuckyDrawMessage($token_no, $number);
//Congrats Message
//$gift_name = "1000 Cashback";
//sendCongratsMessage($gift_name, $number);
//otp message
//sendOtp('111111', $number);*/

 mysqli_close($conn);
 ?>
 