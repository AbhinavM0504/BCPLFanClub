<?php 
    include 'init.php';
    $imeiNo = $_POST['imeiNo'];

    $response = array();
	    
    if(isset($imeiNo)){
    	$sql = "SELECT * FROM `fan_club_gift_imei_table` WHERE imei_no = '".$imeiNo."' ORDER by `id` DESC LIMIT 1";
    	$result = $conn->query($sql);
    	if($result->num_rows > 0) {
    		$model = "";
    		
    		while($row = $result->fetch_assoc()) {
        	    $model = $row["model"];
    	    }
    	    
    	    $response['status'] = true;
    	    $response['message'] = 'Verified';
    	    $response['model'] = $model;
    	    
    	    //echo "Verified";
    	}
    	else{
    	    $response['status'] = false;
    	    $response['message'] = 'Not a Valid IMEI';
    	    $response['model'] = '';
    	    
    		//echo "Not a Valid IMEI";
    	}	
    }
    else{
        $response['status'] = false;
	    $response['message'] = 'Parameter should not be empty';
	    $response['model'] = '';
	    
    	//echo "Parameter should not be empty";
    }
    echo json_encode($response);
    mysqli_close($conn);
?>
 