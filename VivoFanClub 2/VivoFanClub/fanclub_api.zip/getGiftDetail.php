<?php 
    include 'init.php';
    $name = $_POST['name'];
    $number = $_POST['number'];
    $imeiNo = $_POST['imeiNo'];

    $userData = array();
    if(isset($name, $number, $imeiNo)){
    	$sql = "SELECT * FROM `fan_club_data` WHERE `imei_no` = '".$imeiNo."'";
    	$result = $conn->query($sql);
    	if($result->num_rows > 0) {
    		while($row = $result->fetch_assoc()) {
    			$temp = [
    				'gift_detail'=>"".$row["gift_detail"]."",
    				'gift_image'=>"".$row["gift_image"].""
    			];
    			array_push($userData, $temp);
    		}
    		echo json_encode($userData);
    	}
    	else{
    		echo "Not a valid user";
    	}
    }
    else{
    	echo "Parameter should not be empty";
    }
    
    mysqli_close($conn);
?>
 