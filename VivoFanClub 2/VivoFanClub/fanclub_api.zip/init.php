<?php
$server_name = 'localhost';
$username = 'thrsprot_vivo_fan_club_user';
$password = 'fanclub#123';
$db_name = 'thrsprot_vivofanclub';
$conn = new mysqli($server_name,$username,$password,$db_name);
if(!$conn)
{
    echo "Connection error";
}
else{
   //echo "Connection success...";
}
?>