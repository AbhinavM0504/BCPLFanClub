<?php
$server_name = 'localhost';
$username = 'thrsprot_vivo_fan_club_user';
$password = 'fanclub#123';
$db_name = 'thrsprot_vivofanclub';
$conn = new mysqli($server_name,$username,$password,$db_name);
if(!$conn)
{
	echo 'Connection error';
}
else{
	if(isset($_POST['name'], $_POST['password']) && preg_replace('/\s+/', '', $_POST['name']) == 'vivorj' && preg_replace('/\s+/', '', $_POST['password']) =='vivorj'){
?>
<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta content="width=device-width, initial-scale=1.0" name="viewport">
		<title>Fanclub</title>
		<link
			  href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Source+Sans+Pro:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400;1,600;1,700&display=swap"
			  rel="stylesheet">

		<!-- Vendor CSS Files -->
		<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
		<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

		<!-- Variables CSS Files. Uncomment your preferred color scheme -->
		<link href="assets/css/variables.css" rel="stylesheet">

		<!-- Template Main CSS File -->
		<link href="assets/css/main.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
	</head>

	<style>
		#fanclub_table th,
		td {
			white-space: nowrap;
		}

		table.dataTable thead .sorting:after,
		table.dataTable thead .sorting:before,
		table.dataTable thead .sorting_asc:after,
		table.dataTable thead .sorting_asc:before,
		table.dataTable thead .sorting_asc_disabled:after,
		table.dataTable thead .sorting_asc_disabled:before,
		table.dataTable thead .sorting_desc:after,
		table.dataTable thead .sorting_desc:before,
		table.dataTable thead .sorting_desc_disabled:after,
		table.dataTable thead .sorting_desc_disabled:before {
			bottom: .5em;
		}
	</style>

	<body>
		<!--Header-->
		<header id="header" class="header fixed-top" data-scrollto-offset="0">
			<div class="container-fluid d-flex align-items-center justify-content-between">
				<a href="index.php" class="logo d-flex align-items-center scrollto me-auto me-lg-0">
					<h1>BCPL Fanclub</h1>
				</a>
				<nav id="navbar" class="navbar">
					<ul>
						<li class="dropdown"><a href="index.php"><span>Log Out</span></a></li>
					</ul>
					<i class="bi bi-list mobile-nav-toggle d-none"></i>
				</nav>
			</div>
		</header>

		<main id="main">
			<!--Featured Services Section-->
			<section id="featured-services" class="featured-services">
				<div class="container">
					<div class="row">
						<h2 class="text-center"><u>Fanclub Table</u></h2>
					</div>
					<div class="row">
						<div class="col-md-12 table-responsive">
							<table id="fanclub_table" class="table table-striped table-bordered table-hover" width="100%">
								<thead>
									<tr>
										<th>Id</th>
										<th>Fanclub Id</th>
										<th>Name</th>
										<th>Contact No</th>
										<th>IMEI No</th>
										<th>Address</th>
										<th>Customer Image</th>
										<th>Invoice Image</th>
										<th>Latitude_Longitude</th>
										<th>GeoLocation Address</th>
										<th>Pin Code</th>
										<th>Model Purchase</th>
										<th>Old Phone</th>
										<th>Device Brand Name</th>
										<th>Device Model Name</th>
										<th>Device Manufacturer Name</th>
										<th>Device Activation Time</th>
										<th>Gift Name</th>
										<th>Gift Image</th>
										<th>Answer 1</th>
										<th>Answer 2A</th>
										<th>Answer 2B</th>
										<th>Answer 3</th>
										<th>Answer 4A</th>
										<th>Answer 4B</th>
										<th>Answer 5</th>
										<th>Answer 6</th>
										<th>Time</th>
									</tr>
								</thead>
								<tbody>
									<?php
                                		$sql = "SELECT * FROM `fan_club_data`";
                                		$result = mysqli_query($conn, $sql);
                                
                                		if (mysqli_num_rows($result) > 0) {
                                			$a=1;
                                			while($row = mysqli_fetch_assoc($result)) {
                                				$id = "".$row["id"]."";
                                				$token_no = "".$row["token_no"]."";
                                				$name = "".$row["name"]."";
                                				$number = "".$row["number"]."";
                                				$imei_no = "".$row["imei_no"]."";
                                				$address = "".$row["address"]."";
                                				$customer_image = "".$row["customer_image"]."";
                                				$invoice_image = "".$row["invoice_image"]."";
                                				$geo_location_points = "".$row["geo_location_points"]."";
                                				$geo_location_address = "".$row["geo_location_address"]."";
                                				$pin_code = "".$row["pin_code"]."";
                                				$model_purchase = "".$row["model_purchase"]."";
                                				$old_phone_brand = "".$row["old_phone_brand"]."";
                                				$device_brand_name = "".$row["device_brand_name"]."";
                                				$device_model_name = "".$row["device_model_name"]."";
                                				$device_manufacturer_name = "".$row["device_manufacturer_name"]."";
                                				$device_activation_time = "".$row["device_activation_time"]."";
                                				$gift_detail = "".$row["gift_detail"]."";
                                				$gift_image = "".$row["gift_image"]."";
                                				$ans_1_value= "".$row["ans_1_value"]."";
                                				$ans_2A_value = "".$row["ans_2A_value"]."";
                                				$ans_2B_value = "".$row["ans_2B_value"]."";
                                				$ans_3_value = "".$row["ans_3_value"]."";
                                				$ans_4A_value = "".$row["ans_4A_value"]."";
                                				$ans_4B_value = "".$row["ans_4B_value"]."";
                                				$ans_5_value = "".$row["ans_5_value"]."";
                                				$ans_6_value = "".$row["ans_6_value"]."";
                                				$time = "".$row["time"]."";
									?>
									<tr>
										<td><?php echo $a;?></td>
										<td><?php echo $token_no;?></td>
										<td><?php echo $name;?></td>
										<td><?php echo $number;?></td>
										<td><?php echo $imei_no;?></td>
										<td><?php echo $address;?></td>
										<td><?php echo $customer_image;?></td>
										<td><?php echo $invoice_image;?></td>
										<td><?php echo $geo_location_points;?></td>
										<td><?php echo $geo_location_address;?></td>
										<td><?php echo $pin_code;?></td>
										<td><?php echo $model_purchase;?></td>
										<td><?php echo $old_phone_brand;?></td>
										<td><?php echo $device_brand_name;?></td>
										<td><?php echo $device_model_name;?></td>
										<td><?php echo $device_manufacturer_name;?></td>
										<td><?php echo $device_activation_time;?></td>
										<td><?php echo $gift_detail;?></td>
										<td><?php echo $gift_image;?></td>
										<td><?php echo $ans_1_value;?></td>
										<td><?php echo $ans_2A_value;?></td>
										<td><?php echo $ans_2B_value;?></td>
										<td><?php echo $ans_3_value;?></td>
										<td><?php echo $ans_4A_value;?></td>
										<td><?php echo $ans_4B_value;?></td>
										<td><?php echo $ans_5_value;?></td>
										<td><?php echo $ans_6_value;?></td>
										<td><?php echo $time;?></td>
									</tr>

									<?php $a++;
                                			}    
                                		} else 
                                		{
                                			echo "0 results";
                                		}
									?>
								</tbody>
								<tfoot>
									<tr>
										<th>Id</th>
										<th>Fanclub Id</th>
										<th>Name</th>
										<th>Contact No</th>
										<th>IMEI No</th>
										<th>Address</th>
										<th>Customer Image</th>
										<th>Invoice Image</th>
										<th>Latitude_Longitude</th>
										<th>GeoLocation Address</th>
										<th>Pin Code</th>
										<th>Model Purchase</th>
										<th>Old Phone</th>
										<th>Device Brand Name</th>
										<th>Device Model Name</th>
										<th>Device Manufacturer Name</th>
										<th>Device Activation Time</th>
										<th>Gift Name</th>
										<th>Gift Image</th>
										<th>Answer 1</th>
										<th>Answer 2A</th>
										<th>Answer 2B</th>
										<th>Answer 3</th>
										<th>Answer 4A</th>
										<th>Answer 4B</th>
										<th>Answer 5</th>
										<th>Answer 6</th>
										<th>Time</th>
									</tr>
								</tfoot>
							</table>
						</div>
					</div>
				</div>
			</section>
		</main><!-- End #main -->

		<a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

		<!-- Vendor JS Files -->
		<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
		<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

		<!-- Template Main JS File -->
		<script src="assets/js/main.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
		<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
		<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
		<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
		<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
		<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
		<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
		<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
		<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
		<script>
			$(document).ready(function () {
				$('#fanclub_table').DataTable({
					dom: 'Bfrtip',
					buttons: ['excel'],
					"scrollX": true,
					"iDisplayLength": 15,
				});
			});
		</script>
	</body>

</html>

<?php
	}
	else{
		//display form again
?>
<html>
	<head>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

	</head>
	<style>
		/* Importing fonts from Google */
		@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap');

		/* Reseting */
		* {
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			font-family: 'Poppins', sans-serif;
		}

		body {
			background: #ecf0f3;
		}

		.wrapper {
			max-width: 350px;
			min-height: 500px;
			margin: 80px auto;
			padding: 40px 30px 30px 30px;
			background-color: #EF3A3A;
			border-radius: 15px;
			box-shadow: 13px 13px 20px #cbced1, -13px -13px 20px #fff;
		}

		.logo {
			width: 100px;
			margin: auto;
		}

		.logo img {
			width: 100%;
			height: 100px;
			object-fit: cover;
			border-radius: 50%;
			box-shadow: 0px 0px 3px #5f5f5f,
				0px 0px 0px 5px #ecf0f3,
				8px 8px 15px #a7aaa7,
				-8px -8px 15px #fff;
		}

		.wrapper .name {
			font-weight: 600;
			font-size: 1.4rem;
			letter-spacing: 1.3px;
			padding-left: 10px;
			color: #fff;
		}

		.wrapper .form-field input {
			width: 100%;
			display: block;
			border: none;
			outline: none;
			background: none;
			font-size: 1.2rem;
			color: #fff;
			padding: 10px 15px 10px 10px;
			/* border: 1px solid red; */
		}

		.wrapper .form-field {
			padding-left: 10px;
			margin-bottom: 20px;
			border-radius: 20px;
			box-shadow: inset 8px 8px 8px #cbced1, inset -8px -8px 8px #fff;
		}

		.wrapper .form-field .fas {
			color: #555;
		}

		.wrapper .btn {
			box-shadow: none;
			width: 100%;
			height: 40px;
			background-color: #FFFFFF;
			color: #EF3A3A;
			border-radius: 25px;
			box-shadow: 3px 3px 3px #b1b1b1,
				-3px -3px 3px #fff;
			letter-spacing: 1.3px;
		}

		.wrapper .btn:hover {
			background-color: #f5b3b3;
		}

		.wrapper a {
			text-decoration: none;
			font-size: 0.8rem;
			color: #03A9F4;
		}

		.wrapper a:hover {
			color: #039BE5;
		}

		@media(max-width: 380px) {
			.wrapper {
				margin: 30px 20px;
				padding: 40px 15px 15px 15px;
			}
		}

	</style>
	<body>
		<div class="wrapper">
			<div class="logo">
				<!--<img src="https://vivorajstudentprogram.com/prebooking_api/imageV25/app_icon.jpeg" alt="">-->
				<img src="assets/img/app_icon.jpg" alt="">
			</div>
			<div class="text-center mt-4 name">
				BCPL Fanclub
			</div>
			<form class="p-3 mt-3" action='index.php' method='post' onsubmit='validateForm()'>
				<div class="form-field d-flex align-items-center">
					<span class="far fa-user"></span>
					<input type="text" name="name" id="name" placeholder="Username" required>
				</div>
				<div class="form-field d-flex align-items-center">
					<span class="fas fa-key"></span>
					<input type="password" name="password" id="password" placeholder="Password" required>
				</div>
				<button type='submit' name='submit' class="btn mt-3">Submit</button>
			</form>
		</div>
	</body>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<script>
		function validateForm(){
			var username = document.getElementById('name').value.trim();
			var password = document.getElementById('password').value.trim();
			if(username == 'vivorj' && password == 'vivorj'){
				return true;
			}
			else{
				alert('Please enter correct username or password');
			}

		}
	</script>
	<?php
	}
}
	?>