<?php
    $server_name = 'localhost';
    $username = 'thrsprot_vivo_fan_club_user';
    $password = 'fanclub#123';
    $db_name = 'thrsprot_vivofanclub';
    $conn = new mysqli($server_name,$username,$password,$db_name);
    
    $userData = array();
    $response = array();
        
    if(!$conn){
        $response['status'] = false;
		$response['message'] = "Connection Error";
    }
    else{
        $sql = "SELECT * FROM `fan_club_data` order by `id` desc";
    	$result = mysqli_query($conn, $sql);
    	if (mysqli_num_rows($result) > 0) {
    		
    		while($row = mysqli_fetch_assoc($result)) {
    			
    			$temp = [
    				'token_no'=>"".$row['token_no']."",
    				'name'=>"".$row['name']."",
    				'number'=>"".$row['number'].""
    			];
    			array_push($userData, $temp);
    		}
    		$response['status'] = true;
            $response['message'] = $userData;
            
            echo json_encode($userData);
            
    	}
    	else {
    		$response['status'] = false;
    		$response['message'] = "No matching data available";
            
            echo json_encode($response);
    	}
        $conn->close();
    }
?>