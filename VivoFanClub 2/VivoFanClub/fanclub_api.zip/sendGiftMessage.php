<?php 
    include 'init.php';
    $name = $_POST['name'];
    $number = $_POST['number'];
    $imeiNo = $_POST['imeiNo'];

    $userData = array();

    //send message
    function sendCongratsMessage($gift_name, $number){
	    $curl = curl_init();
    	curl_setopt_array($curl, array(
	        CURLOPT_URL => "http://sms.jaipursmshub.in/api_v2/message/send",
	        CURLOPT_RETURNTRANSFER => true,
	        CURLOPT_ENCODING => "",
    	    CURLOPT_MAXREDIRS => 10,
    	    CURLOPT_TIMEOUT => 30,
    	    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	        CURLOPT_CUSTOMREQUEST => "POST",
    	    CURLOPT_POSTFIELDS => "sender_id=621157&dlt_template_id=1207166564292284055&message=Thank You for participating in vivo Diwali Lucky Draw Bonanza.
Congratulations You have won ".$gift_name."
Bubugao Communication Private Limited&mobile_no='".$number."'",
    	  CURLOPT_HTTPHEADER => array(
    		"authorization: Bearer bRjbloPfvBU-2mHgdvI49XO--ue4Gk_DD6y80CN5liESVhRsGf_R3W8f9JJM_NTt",
    		"cache-control: no-cache",
    		"content-type: application/x-www-form-urlencoded"
    	  ),
    	));
    
    	$response = curl_exec($curl);
    	$err = curl_error($curl);
    
    	curl_close($curl);
    	
    	if ($err) {
    	  echo "cURL Error #:" . $err;
    	} else {
    	  echo "Message Sent Successfully...";
    	}
    }
    
    /*function sendCongratsMessage($gift_name, $number){
	    $office_number = '9799653222';
	    $curl = curl_init();
    	curl_setopt_array($curl, array(
	        CURLOPT_URL => "http://sms.jaipursmshub.in/api_v2/message/send",
	        CURLOPT_RETURNTRANSFER => true,
	        CURLOPT_ENCODING => "",
    	    CURLOPT_MAXREDIRS => 10,
    	    CURLOPT_TIMEOUT => 30,
    	    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	        CURLOPT_CUSTOMREQUEST => "POST",
    	    CURLOPT_POSTFIELDS => "sender_id=RJVIVO&dlt_template_id=1207163980648921300&message=Thank You for participating in Christmas Lucky Draw Bonanza. 
    Congratulations You have won '".$gift_name."'
    For more details contact us at '".$office_number."'&mobile_no='".$number."'",
    	  CURLOPT_HTTPHEADER => array(
    		"authorization: Bearer bRjbloPfvBU-2mHgdvI49XO--ue4Gk_DD6y80CN5liESVhRsGf_R3W8f9JJM_NTt",
    		"cache-control: no-cache",
    		"content-type: application/x-www-form-urlencoded"
    	  ),
    	));
    
    	$response = curl_exec($curl);
    	$err = curl_error($curl);
    
    	curl_close($curl);
    	
    	if ($err) {
    	  echo "cURL Error #:" . $err;
    	} else {
    	  echo "Message Sent Successfully...";
    	}
    }

    function sendLuckyDrawMessage($token_no, $number){
	    $office_number = '9799653222';
	    $curl = curl_init();
	    curl_setopt_array($curl, array(
	        CURLOPT_URL => "http://sms.jaipursmshub.in/api_v2/message/send",
	        CURLOPT_RETURNTRANSFER => true,
	        CURLOPT_ENCODING => "",
	        CURLOPT_MAXREDIRS => 10,
	        CURLOPT_TIMEOUT => 30,
	        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	        CURLOPT_CUSTOMREQUEST => "POST",
	        CURLOPT_POSTFIELDS => "sender_id=RJVIVO&dlt_template_id=1207163980682628805&message=Thank You for participating in Christmas Lucky Draw Bonanza.
        You are now eligible for Mega Lucky Draw Prize which will be live on 28th December 2021 at vivo official Facebook Page.
        Follow us bit.ly/3JcakQv to Join the Facebook live session.
        Your Ticket Number is '".$token_no."'.
        For more details contact us at '".$office_number."'. &mobile_no='".$number."'",
	        CURLOPT_HTTPHEADER => array(
		        "authorization: Bearer bRjbloPfvBU-2mHgdvI49XO--ue4Gk_DD6y80CN5liESVhRsGf_R3W8f9JJM_NTt",
		        "cache-control: no-cache",
		        "content-type: application/x-www-form-urlencoded"
	        ),
	    ));

	    $response = curl_exec($curl);
	    $err = curl_error($curl);

	    curl_close($curl);
	
	    if ($err) {
	    echo "cURL Error #:" . $err;
	    } else {
	    echo "Message Sent Successfully...";
	    }
    }*/


    if(isset($name, $number, $imeiNo)){
	    //echo "Lucky draw contest has been closed now!!!!";
	    $sql = "SELECT * FROM `fan_club_data` WHERE `imei_no` = '".$imeiNo."' order by id desc limit 1";
	    $result = $conn->query($sql);
	    if($result->num_rows > 0) {
		    while($row = $result->fetch_assoc()) {
    			$token_no = "".$row["token_no"]."";
    			$gift_detail = "".$row["gift_detail"]."";
    			
    			if($gift_detail == 'cashback_250'){
    				$gift_name = "250 Cashback";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'cashback_500'){
    				$gift_name = "500 Cashback";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'cashback_1000'){
    				$gift_name = "1000 Cashback";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'vivo_accessories_5'){
    				$gift_name = "5% discount on vivo accessories and coupon code is DIWALIOFF5";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'vivo_accessories_10'){
    				$gift_name = "10% discount on  vivo accessories and coupon code is DIWALIDISC10";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'vivo_accessories_15'){
    				$gift_name = "15% discount on vivo accessories and coupon code is DIWALIOFF15";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'bluetooth_speaker'){
    				$gift_name = "Bluetooth Speaker";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'ev_scooty'){
    				$gift_name = "EV Scooty";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'insta_mini'){
    				$gift_name = "Insta Mini";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'room_heater'){
    				$gift_name = "Room Heater";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'instant_cashback'){
    				$gift_name = "Instant Cashback";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'led'){
    				$gift_name = "LED Tv";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'washing_machine'){
    				$gift_name = "Washing Machine";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'bluetooth_neckbend'){
    				$gift_name = "Bluetooth Neckbend";
    				sendCongratsMessage($gift_name, $number);
    			}
    			else if($gift_detail == 'music_system'){
    				$gift_name = "Sony Music System";
    				sendCongratsMessage($gift_name, $number);
    			}
    		}
    	}
    }
    else{
    	echo "Parameter should not be empty";
    }
    
    
    mysqli_close($conn);
?>
 