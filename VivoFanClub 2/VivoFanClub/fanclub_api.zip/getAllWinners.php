<?php 
    include 'init.php';

    $response = array();
    $winnerData = array();
    
    $sql = "SELECT * FROM `fan_club_winner_data`";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
    	while($row = $result->fetch_assoc()) {
    		$temp = [
    			'winners_name'=>"".$row["winners_name"].""
    		];
    		array_push($winnerData, $temp);
    	}
    	$response['status'] = true;
        $response['message'] = $winnerData;
    }
    else{
        $response['status'] = false;
        $response['message'] = "No winners available...";
    }
    
    echo json_encode($response);
    
    mysqli_close($conn);
?>
 