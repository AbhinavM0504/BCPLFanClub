<?php
    // Create connection
    include 'init.php';
    
    //set time zone
    date_default_timezone_set("Asia/Kolkata");
        
    //get parameters
    $name = $_POST['name'];
    $number = $_POST['number'];
    $imeiNo = $_POST['imeiNo'];
    $address = $_POST['address'];
    $pin = $_POST['pin'];
    $modelPurchase = $_POST['modelPurchase'];
    $oldPhoneBrand = $_POST['oldPhoneBrand'];
    $locationPoints = $_POST['locationPoints'];
    $locationAddress = $_POST['locationAddress'];
    //device details
    $brandName = $_POST['brandName'];
    $modelName = $_POST['modelName'];
    $manufacturerName = $_POST['manufacturerName'];
    $activationTime = $_POST['activationTime'];
    
    $response = array();

    if(isset($name, $number, $imeiNo, $address, $pin, $modelPurchase, $oldPhoneBrand)){
    	
    	$gift_detail = "";
    	$gift_image = "";
    	
    	$check_no_sql = "SELECT * from fan_club_data WHERE `number`='".$number."' OR `imei_no` = '".$imeiNo."'";
    	$check_no_result = $conn->query($check_no_sql);
    	if ($check_no_result->num_rows > 0) {
    	    $response['status'] = true;
    	    $response['message'] = "This imei number or contact number is already registered...";
    	}
    	else{
    		$check_imei_sql = "SELECT * from fan_club_gift_imei_table WHERE `imei_no` = '".$imeiNo."' limit 1";
    		$result = $conn->query($check_imei_sql);
    		if ($result->num_rows > 0) {
    			while($row = $result->fetch_assoc()) {
    				$gift_detail = "".$row["gift_name"]."";
    				$gift_image = "https://3sprotect.com/fanclub_api/gift_image/".$gift_detail.".jpeg";
                    
                    $time = date('Y-m-d H:i:s');
    				$insert_sql = "INSERT INTO `fan_club_data`(`name`, `number`, `imei_no`, `address`, `geo_location_points`, `geo_location_address`, `pin_code`, `model_purchase`, `old_phone_brand`, `device_brand_name`, `device_model_name`, `device_manufacturer_name`, `device_activation_time`, `gift_detail`, `gift_image`, `time`) 
    				VALUES ('".$name."', '".$number."', '".$imeiNo."', '".$address."', '".$locationPoints."', '".$locationAddress."', '".$pin."', '".$modelPurchase."',  '".$oldPhoneBrand."', '".$brandName."', '".$modelName."', '".$manufacturerName."',  '".$activationTime."', '".$gift_detail."', '".$gift_image."', '".$time."')";
    
        			if(mysqli_query($conn, $insert_sql)){
        				$last_id = $conn->insert_id;//fetch last id
        				$series = "XMAS00";
        				$token_no = $series.$last_id;//generate toke number
        				$sqll = "update fan_club_data set token_no = '$token_no' where `id`=$last_id";//update to database
        				if(mysqli_query($conn, $sqll))
        				{
        				    $response['status'] = true;
    	                    $response['message'] = "Data has been saved successfully !!!";
        				}
        			}
        			else{
        				$response['status'] = false;
                        $response['message'] = "Unable to save data...";
        			}
    			}
    		}
    	}
    }
    else{
        $response['status'] = false;
        $response['message'] = "Please fill all the details";
    }
    
    echo json_encode($response);
    $conn->close();
?>