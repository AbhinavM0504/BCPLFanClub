<?php 
    include 'init.php';
    
    //set time zone
    date_default_timezone_set("Asia/Kolkata");
    
    /*// Check connection
    $response = array();
    if (mysqli_connect_errno())
    {
        $response['status'] = false;
        $response['message'] = "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    else
    { 
        $json = json_decode(file_get_contents('php://input'),true);
       
        $name = $json["name"]; 
        $number = $json["number"]; 
        $imeiNo = $json["imeiNo"]; 
        $address = $json["address"]; 
        $pin = $json["pin"]; 
        $modelPurchase = $json["modelPurchase"]; 
        $oldPhoneBrand = $json["oldPhoneBrand"]; 
        $locationPoints = $json["locationPoints"]; 
        $locationAddress = $json["locationAddress"]; 
        $customerImageName = $json["customerImageName"]; 
        $customerImage = $json["customerImage"]; 
        $customerInvoiceImageName = $json["customerInvoiceImageName"]; 
        $customerInvoiceImage = $json["customerInvoiceImage"]; 
        
        //device details
        $brandName = $json["brandName"]; 
        $modelName = $json["modelName"]; 
        $manufacturerName = $json["manufacturerName"]; 
        $activationTime = $json["activationTime"]; 
        
        //answer values
        $ans_1_value = $json["ans_1_value"]; 
        $ans_2A_value = $json["ans_2A_value"]; 
        $ans_2B_value = $json["ans_2B_value"]; 
        $ans_3_value = $json["ans_3_value"]; 
        $ans_4A_value = $json["ans_4A_value"]; 
        $ans_4B_value = $json["ans_4B_value"]; 
        $ans_5_value = $json["ans_5_value"]; 
        $ans_6_value = $json["ans_6_value"]; 

        
        if(isset($name, $number, $imeiNo, $address, $pin, $modelPurchase, $oldPhoneBrand)){
                	
        	$check_no_sql = "SELECT * from fan_club_data WHERE `number`='".$number."' OR `imei_no` = '".$imeiNo."'";
        	$check_no_result = $conn->query($check_no_sql);
        	if ($check_no_result->num_rows > 0) {
        	    $response['status'] = false;
        	    $response['message'] = "This imei number or contact number is already registered...";
        	}
        	else{
        	    $folder = "/home1/thrsprot/public_html/fanclub_api/images/";
            
                //upload customer image
                $customer_decoded_image = base64_decode("$customerImage");
                $c_image_return = file_put_contents($folder.$customerImageName, $customer_decoded_image);
                if($c_image_return !== false){
                    $image_link = "https://3sprotect.com/fanclub_api/images/";
                    
                    //upload invoice image
                    $invoice_decoded_image = base64_decode("$customerInvoiceImage");
                    $invoice_image_return = file_put_contents($folder.$customerInvoiceImageName, $invoice_decoded_image);
                    if($invoice_image_return !== false){
                    
                        //save gift details
                        $gift_detail = "";
                    	$gift_image = "";
                    	
                    	$check_no_sql_1 = "SELECT * from fan_club_data WHERE `number`='".$number."' OR `imei_no` = '".$imeiNo."'";
                    	$check_no_result_1 = $conn->query($check_no_sql_1);
                    	if ($check_no_result_1->num_rows > 0) {
                    	    $response['status'] = false;
                    	    $response['message'] = "This imei number or contact number is already registered...";
                    	}
                    	else{
                    		$check_imei_sql = "SELECT * from fan_club_gift_imei_table WHERE `imei_no` = '".$imeiNo."' ORDER by `id` DESC limit 1";
                    		$result = $conn->query($check_imei_sql);
                    		if ($result->num_rows > 0) {
                    			while($row = $result->fetch_assoc()) {
                    				$gift_detail = "".$row["gift_name"]."";
                    				$gift_image = "https://3sprotect.com/fanclub_api/gift_image/".$gift_detail.".jpeg";
                                    
                                    $time = date('Y-m-d H:i:s'); 
                                    
                                    $customer_image = $image_link.$customerImageName;
                                    $invoce_image = $image_link.$customerInvoiceImageName;
                                    $insert_sql = "INSERT INTO `fan_club_data`(`name`, `number`, `imei_no`, `address`, `customer_image`, `invoice_image`, `geo_location_points`, `geo_location_address`,
                                                                                `pin_code`, `model_purchase`, `old_phone_brand`, `device_brand_name`, `device_model_name`, `device_manufacturer_name`, 
                                                                                `device_activation_time`, `gift_detail`, `gift_image`, `ans_1_value`, `ans_2A_value`, `ans_2B_value`, `ans_3_value`, 
                                                                                `ans_4A_value`, `ans_4B_value`, `ans_5_value`, `ans_6_value`, `time`) 
                                                                            VALUES ('".$name."', '".$number."', '".$imeiNo."', '".$address."', '".$customer_image."', '".$invoce_image."', '".$locationPoints."', '".$locationAddress."', 
                                                                            '".$pin."', '".$modelPurchase."', '".$oldPhoneBrand."', '".$brandName."', '".$modelName."', '".$manufacturerName."', 
                                                                            '".$activationTime."', '".$gift_detail."', '".$gift_image."', '".$ans_1_value."', '".$ans_2A_value."', '".$ans_2B_value."', '".$ans_3_value."',
                                                                            '".$ans_4A_value."', '".$ans_4B_value."', '".$ans_5_value."', '".$ans_6_value."', '".$time."')";
                                    
                        			if(mysqli_query($conn, $insert_sql)){
                        				$last_id = $conn->insert_id;//fetch last id
                        				$series = "VLDS00";
                        				$token_no = $series.$last_id;//generate toke number
                        				$sqll = "update fan_club_data set token_no = '$token_no' where `id`=$last_id";//update to database
                        				if(mysqli_query($conn, $sqll))
                        				{
                        				    $response['status'] = true;
                    	                    $response['message'] = "Data has been saved successfully !!!";
                        				}
                        			}
                        			else{
                        				$response['status'] = false;
                                        $response['message'] = "Unable to save data...";
                        			}
                    			}
                    		}
                    	}
        	
                    }
                    else{
                        $response['status'] = false;
                        $response['message'] = "Invoice Image Upload Failed";
                    }
                }
                else
                {
                    $response['status'] = false;
                    $response['message'] = "Customer Image Upload Failed";
                }
        	}
        }
        else{
            $response['status'] = false;
            $response['message'] = "Please fill all the details...";
        }
    }*/
    
    $response['status'] = false;
    $response['message'] = "Diwali Lucky Draw contest has been closed now...";
        
    echo json_encode($response);
?>