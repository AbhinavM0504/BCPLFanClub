<?php 
    include 'init.php';
    
    $contactNo = $_POST['contactNo'];

    $response = array();
    if(isset($contactNo)){
    	$sql = "SELECT * FROM `fan_club_data` WHERE number = '".$contactNo."' ORDER by `id` DESC LIMIT 1";
    	$result = $conn->query($sql);
    	if($result->num_rows > 0) {
    	    $giftName = "";
    	    $giftMessage = "";
    	    $giftImage = "";
        	while($row = $result->fetch_assoc()) {
        	    $gift = $row["gift_detail"];
        	    if($gift == 'vivo_accessories_5'){
        	        $giftName = "5% discount on vivo accessories";
        	        $giftMessage = "Congratulation you have won ".$giftName." and coupon code is DIWALIOFF5";
        	    }
        	    else if($gift == 'vivo_accessories_10'){
        	        $giftName = "10% discount on vivo accessories";
        	        $giftMessage = "Congratulation you have won ".$giftName." and coupon code is DIWALIDISC10";
        	    }
        	    else if($gift == 'vivo_accessories_15'){
        	        $giftName = "10% discount on vivo accessories";
        	        $giftMessage = "Congratulation you have won ".$giftName." and coupon code is DIWALIOFF15";
        	    }
        	    else if($gift == 'cashback_250'){
        	        $giftName = "250 Cashback";
        	        $giftMessage = "Congratulation you have won ".$giftName;
        	    }
        	    else if($gift == 'cashback_500'){
        	        $giftName = "500 Cashback";
        	        $giftMessage = "Congratulation you have won ".$giftName;
        	    }
        	    else if($gift == 'cashback_1000'){
        	        $giftName = "1000 Cashback";
        	        $giftMessage = "Congratulation you have won ".$giftName;
        	    }
        	    else if($gift == 'instax_mini'){
        	        $giftName = "Instax Mini";
        	        $giftMessage = "Congratulation you have won ".$giftName;
        	    }
        	    else if($gift == 'room_heater'){
        	        $giftName = "Room Heater";
        	        $giftMessage = "Congratulation you have won ".$giftName;
        	    }
        	    else if($gift == 'led'){
        	        $giftName = "LED TV";
        	        $giftMessage = "Congratulation you have won ".$giftName;
        	    }
        	    else if($gift == 'washing_machine'){
        	        $giftName = "Washing Machine";
        	        $giftMessage = "Congratulation you have won ".$giftName;
        	    }
        	    else if($gift == 'bluetooth_neckbend'){
        	        $giftName = "Bluetooth Neckbend";
        	        $giftMessage = "Congratulation you have won ".$giftName;
        	    }
        	    else if($gift == 'music_system'){
        	        $giftName = "Music System";
        	        $giftMessage = "Congratulation you have won ".$giftName;
        	    }
        	    else if($gift == 'bluetooth_speaker'){
        	        $giftName = "Bluetooth Speaker";
        	        $giftMessage = "Congratulation you have won ".$giftName;
        	    }
        	    else if($gift == 'ev_scooty'){
        	        $giftName = "EV Scooty";
        	        $giftMessage = "Congratulation you have won ".$giftName;
        	    }
        	    else{
        	        $giftMessage = "Congratulation you have won ".$gift;
        	    }
        	    $giftImage = $row["gift_image"];
    	    }
    	    $response['status'] = true;
            $response['message'] = $giftMessage;
            $response['image'] = $giftImage;
    	}
    	else{
    		$response['status'] = false;
            $response['message'] = "This number is not included in lucky draw bonanza. Please participate first...";
            $response['image'] = "";
    	}
    }
    else{
        $response['status'] = false;
        $response['message'] = "Not a valid contact no..";
        $response['image'] = "";
    }
    
    echo json_encode($response);
    mysqli_close($conn);
?>
 